package com.crm.qa.utils;

import com.crm.qa.base.TestBase;

public class TestUtils extends TestBase
{
	public static long PAGE_LOAD_TIMEOUT=10;
	public static long IMPLICITS_WAIT=10;
	
	public void switchToFrame()
	{
		driver.switchTo().frame("mainpanel");
	}

}
