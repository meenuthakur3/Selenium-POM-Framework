package com.crm.qa.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.crm.qa.utils.TestUtils;

public class TestBase 
{
	public static WebDriver  driver;
	public static Properties prop;
	
	public TestBase() 
	{
		prop=new Properties();
		FileInputStream fi;
		try {
			String url=System.getProperty("user.dir")+"/src/main/java/com/crm/qa/config/config.properties";
			fi = new FileInputStream(url);
			prop.load(fi);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}		
		
	}
	
	public static void instalization()
	{
		String browserName=prop.getProperty("browser");
		if(browserName.equals("chrome"))
		{
			 driver=new ChromeDriver();
		}
		else if (browserName.equals("firefox"))
		{
			driver=new FirefoxDriver();
			
		}
		else if(browserName.equals("edge"))
		{
			driver=new EdgeDriver();
			
		}
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		 driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(TestUtils.PAGE_LOAD_TIMEOUT));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(TestUtils.IMPLICITS_WAIT));
		driver.get(prop.getProperty("url"));
       
	}

}
