package co.crm.qa.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.crm.qa.base.TestBase;

public class HomePage extends TestBase {
	@FindBy(xpath = "//*[@id=\'userName-value\']")
	WebElement ProfileUserName;
	@FindBy(xpath = "//*[@id=\'gotoStore\']")
	WebElement GoToBookStore;
	@FindBy(xpath = "//*[@id=\'app\']/div/div/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]")
	List<WebElement> listOfBooks;
	@FindBy(xpath = "//div[@class='element-group'][1]")
	WebElement element;
	@FindBy(xpath="//div[text()='Book Store Application']")
	WebElement BooksMenu;

	public HomePage() {
		PageFactory.initElements(driver, this);

	}

	public String verifyUserName() {
		return ProfileUserName.getText();

	}

	public boolean verifyGoToBookStoreBtn() {
		return GoToBookStore.isDisplayed();

	}

	public int getListOfBooks() {
		return listOfBooks.size();

	}
	public ElementsPage ClickOnElements() {
		element.click();
		return new ElementsPage();

	}
	public SearchPage clickOnBooksElemet()
	  {
		BooksMenu.click();
		return new SearchPage();
		  
	  }

}
