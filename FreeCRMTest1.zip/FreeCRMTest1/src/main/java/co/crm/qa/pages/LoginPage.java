package co.crm.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.crm.qa.base.TestBase;

public class LoginPage extends TestBase
{
	//Page Factory-Object Repo
	@FindBy(id="userName")
	WebElement userName;
	@FindBy(id="password")
	WebElement UserPassword;
	@FindBy(id="login")
	WebElement loginBtn;
	//Three page Factory define
	
	@FindBy(xpath = "//*[@id='app']/header/a/img")
	WebElement LogoImg;
	
	//Sign In Page Fctory
	@FindBy(xpath="//*[@id=\"newUser\"]")
	WebElement NewUser;
	
	//Intalizing the Page Object
	public LoginPage()
	{
		PageFactory.initElements(driver, this);
		
	}
	//Actions-On Page
	public String ValidateLoginPageTitle()
	{
		return  driver.getTitle();
	}
	
	public boolean validateLogoImage() 
	{
		return LogoImg.isDisplayed();
		
	}
	public HomePage login(String username,String password)
	{
		userName.sendKeys(username);
		UserPassword.sendKeys(password);
		loginBtn.click();
		return new  HomePage();
	}
	
	

}
