package co.crm.qa.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.crm.qa.base.TestBase;

public class ElementsPage extends TestBase {
	@FindBy(xpath = "//div[@class='element-group'][1]")
	WebElement element;
	@FindBy(xpath = "//*[@id=\"item-0\"]")
	List<WebElement> ListOfElements;
	@FindBy(xpath = "//*[@id=\'item-0\']")
	WebElement textItem;
	@FindBy(xpath = " //*[@id='userName']")
	WebElement TextInputField;
	@FindBy(xpath = "//*[@id=\'item-1\']")
	WebElement checkBox;
	@FindBy(xpath = "//*[@id=\'tree-node\']/ol/li/span/label")
	WebElement checkBoxVisible;
	@FindBy(xpath = "//*[@id=\'item-2\']")
	WebElement RadioButton;
	@FindBy(xpath = "//div[@class='custom-control custom-radio custom-control-inline'][1]")
	WebElement RadionBtnVisible;
	@FindBy(xpath = "//*[@id=\'item-3\']")
	WebElement WebTables;
	@FindBy(xpath = "//div[@class='ReactTable -striped -highlight']")
	WebElement WebtableVisible;
	

	public ElementsPage()
	{
		PageFactory.initElements(driver, this);
	}

	public boolean ElemestBtnVisible() {
		return element.isDisplayed();
	}

	public int ListOfelementsVisible() {
		return ListOfElements.size();

	}

	public boolean validateTextBox() {
		textItem.click();
		return TextInputField.isDisplayed();

	}

	public boolean validateCheckBox() {
		checkBox.click();
		return checkBoxVisible.isDisplayed();

	}

	public boolean validateRadio() {
		RadioButton.click();
		return RadionBtnVisible.isDisplayed();

	}

	public boolean validateWebTables() {
		WebTables.click();
		return WebtableVisible.isDisplayed();

	}
  
}
