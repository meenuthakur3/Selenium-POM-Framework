package co.crm.qa.pages;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.crm.qa.base.TestBase;
public class SearchPage extends TestBase
{
	@FindBy(xpath="//*[@id=\'searchBox\']")
	WebElement serchIcon;
	@FindBy(xpath="//*[@id=\"app\"]/div/div/div/div[2]/div[2]/div[3]/div[3]")
	WebElement deleteBooks;
	
	public SearchPage() 
	{
        PageFactory.initElements(driver, this);
    }

    // Method to enter text in search box
    public boolean verifySeacrhIcon()
    {
    	 return (serchIcon.isDisplayed());
    }

    public boolean clickDeleteButtonAndHandleAlert() throws InterruptedException {
        deleteBooks.click(); 
        Thread.sleep(4000);
        Alert alert = driver.switchTo().alert();
        alert.accept(); 
        return true;
        }

}
