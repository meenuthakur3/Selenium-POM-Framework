package com.crm.qa.test;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import com.crm.qa.base.TestBase;
import co.crm.qa.pages.HomePage;
import co.crm.qa.pages.LoginPage;



public class LoginPageTest  extends TestBase
{
	LoginPage LoginPageobj;
	HomePage HomePageObj;
	
	public LoginPageTest() {
		super(); // this will call the super class constructor
	}
	
	@BeforeMethod
	public void setUp()
	{
		 //LoginPageobj = new LoginPage(); 
		instalization();
		LoginPageobj=new LoginPage();
		HomePageObj=new HomePage();
		
	}
	@Test(priority = 1)
	public void LoginPageTitleTest()
	{
		String title=LoginPageobj.ValidateLoginPageTitle();
		Assert.assertEquals(title,"DEMOQA");
	}
	@Test (priority = 2)
	public void PageLogoTest()
	{
		Boolean flag= LoginPageobj.validateLogoImage();
		Assert.assertEquals(flag,true);
	}
	@Test(priority=3)
	public void loginTest()
	{
		HomePageObj= LoginPageobj.login(prop.getProperty("user"),prop.getProperty("password"));
		
	}
	@AfterMethod
		public void tearDown()
		{
			driver.quit();
		}
	
	

}
