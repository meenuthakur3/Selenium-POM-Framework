package com.crm.qa.test;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.crm.qa.base.TestBase;
import co.crm.qa.pages.HomePage;
import co.crm.qa.pages.LoginPage;
import co.crm.qa.pages.SearchPage;

public class SearchPageTest extends TestBase
{LoginPage loginObj;
HomePage HomeObj;
SearchPage SearchObj;

 public SearchPageTest() {
	  super();
}

@BeforeMethod
	
	public void Setup() throws InterruptedException
	{
		instalization();
		 loginObj=new LoginPage();
		 SearchObj =new SearchPage();
		 Thread.sleep(5000);
		HomeObj=new HomePage();
		HomeObj=loginObj.login(prop.getProperty("user"),prop.getProperty("password"));
		SearchObj=HomeObj.clickOnBooksElemet();
		Thread.sleep(5000);					
	}
@Test (priority=1)
public void verifySearchIconIsVisible()
{
	boolean a=SearchObj.verifySeacrhIcon();
	Assert.assertEquals(a, true ,"Search icon are visible");
}
@Test(priority = 2)
public void clickonDeleteBooks() throws InterruptedException
{
	boolean val=SearchObj.clickDeleteButtonAndHandleAlert();
	Assert.assertEquals(val,true,"Books is not deleted");
	
}
@AfterMethod
public void tearDown()
{
	driver.quit();
}

}
