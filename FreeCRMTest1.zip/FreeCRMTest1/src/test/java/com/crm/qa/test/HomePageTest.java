package com.crm.qa.test;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.crm.qa.base.TestBase;

import co.crm.qa.pages.ElementsPage;
import co.crm.qa.pages.HomePage;
import co.crm.qa.pages.LoginPage;

public class HomePageTest extends TestBase
{
	HomePage HomePageObj;
	LoginPage loginObj;
	public HomePageTest() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	@BeforeMethod
	
	public void Setup() throws InterruptedException
	{
		instalization();
		 loginObj=new LoginPage();
		//HomePageObj=new HomePage();
		HomePageObj=loginObj.login(prop.getProperty("user"),prop.getProperty("password"));
		Thread.sleep(5000);
		
	}
	@Test(priority = 1)
	public void verifyUserName()
	{
		String name=HomePageObj.verifyUserName();
		Assert.assertEquals(name,prop.getProperty("user") );
	}
	@Test(priority = 2)
	public void clickBtnViewBooks()
	{
		boolean flag=HomePageObj.verifyGoToBookStoreBtn();
		Assert.assertEquals(flag, true);
	}
	@Test(priority = 3)
	public ElementsPage ListOfBooks()
	{
		int a=HomePageObj.getListOfBooks();
		System.out.println("Size is"+a);
		return new ElementsPage();
		//Assert.assertEquals(false, null);
	}
	@AfterMethod
	public void tearDown()
	{
		driver.quit();
	}

}
