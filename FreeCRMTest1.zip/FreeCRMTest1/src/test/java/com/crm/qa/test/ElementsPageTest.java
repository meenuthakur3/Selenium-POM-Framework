package com.crm.qa.test;

import static org.testng.Assert.assertEquals;

import org.junit.After;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.crm.qa.base.TestBase;
import co.crm.qa.pages.ElementsPage;
import co.crm.qa.pages.HomePage;
import co.crm.qa.pages.LoginPage;


public class ElementsPageTest extends TestBase
{
	ElementsPage eleobj;
	LoginPage loginObj;
	HomePage HomeObj;
  public ElementsPageTest()
  {
	  super();
  }
  
  @BeforeMethod
	
	public void Setup() throws InterruptedException
	{
		instalization();
		 loginObj=new LoginPage();
		 eleobj =new ElementsPage();
		 Thread.sleep(5000);
		HomeObj=new HomePage();
		HomeObj=loginObj.login(prop.getProperty("user"),prop.getProperty("password"));
		eleobj=HomeObj.ClickOnElements();
		Thread.sleep(5000);		
	}
  
  @Test(priority = 1)
  public void veifyElementsBtnVisible()
  {
	 boolean btn= eleobj.ElemestBtnVisible();
	 Assert.assertEquals(btn,true,"Elemets is Vissible");
  }
  @Test(priority = 2)
  public void verifyListOfElemets()
  {
	  int a=eleobj.ListOfelementsVisible();
	  Assert.assertEquals(a, 6,"List of elemets is not correct");
  }
  @Test(priority = 3)
  public void verifyTextBoxVisisble()
  {
	 boolean result=eleobj.validateTextBox();
	 Assert.assertEquals(result, true,"Text Box is Visible");
	 
  }
  @Test(priority = 4)
  public void verifyCheckBoxVisisble()
  {
	 boolean result=eleobj.validateCheckBox();
	 Assert.assertEquals(result, true,"Check Box is Visible");
	 
  }
  @Test(priority = 5)
  public void verifyRadioButtonVisisble()
  {
	 boolean result=eleobj.validateRadio();
	 Assert.assertEquals(result, true,"Radio Button is Visible");
	
  }
  @Test (priority = 6) 
  public void verifyWebTableVisisble()
  {
	 boolean result=eleobj.validateWebTables();
	 Assert.assertEquals(result, true,"WebTables is Visible");
	 
  } 
  
  @AfterMethod
  public void closeDriver()
  {
	  driver.quit();
  }
  
}
